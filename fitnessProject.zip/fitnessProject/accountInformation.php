<?
    $a = 5;
    $b = 8;
    $out = json_encode(array(
    	num1 = $a,
    	num2 = $b
    ));
    echo $out;
?>
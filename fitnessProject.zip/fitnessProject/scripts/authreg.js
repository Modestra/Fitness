function enterInSite(){
    window.open("D:/Fitness/fitnessProject/main.html")
    this.close()
}
function registration(){
    window.open("D:/Fitness/fitnessProject/registration.html")
    this.close()
}
function authorisation(){
    window.open("D:/Fitness/fitnessProject/authorization.html")
    this.close()
}
function Itrains(){
    document.getElementById('mainFrame').src = "trainslist.html"
}
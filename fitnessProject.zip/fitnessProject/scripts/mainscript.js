function trains(){
    window.open("../fitnessProject/trainslist.html")
}
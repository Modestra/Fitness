document.addEventListener("DOMContentLoaded", (data, err)=>{
    console.log("Скрипт запущен")
})